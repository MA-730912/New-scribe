# AI Medical Voice Scribe

This is a full-featured React + Next.js app with voice-to-text, AI summarisation, and PDF export.