export default function Home() {
  return (
    <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>🩺 AI Voice Scribe App</h1>
      <p>This is your deployed homepage on Vercel.</p>
      <p>Start building features like voice-to-text, summaries, and PDF export here.</p>
    </main>
  );
}